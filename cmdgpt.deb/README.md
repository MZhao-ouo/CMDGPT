# CMDGPT
A CLI tool to interact with GPT-3.5-turbo
